import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Set high-DPI figure
fig = plt.figure(figsize=(18, 10.2), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 100)
ax.set_ylim(0, 56)
ax.axis('off')

# Background
fig.patch.set_facecolor('#f8fafc')
ax.set_facecolor('#f8fafc')

# Main Title Header
title_box = patches.FancyBboxPatch((1.5, 48.5), 97, 6.2, boxstyle="round,pad=0.3,rounding_size=0.8",
                                  facecolor='#0f172a', edgecolor='#0284c7', linewidth=2.5)
ax.add_patch(title_box)

ax.text(50, 52.8, "AUTONOMOUS RAILWAY ROBOT SIMULATION — SYSTEM ARCHITECTURE",
        ha='center', va='center', fontsize=18, fontweight='bold', color='#ffffff', fontfamily='sans-serif')
ax.text(50, 50.2, "Dual-Track Corridor Patrol  •  4-DOF Arm with 535L Pouch  •  Articulated Leveler Plow  •  k-NN Decision & GD Gain Optimizer",
        ha='center', va='center', fontsize=11, fontweight='medium', color='#94a3b8', fontfamily='sans-serif')

# Column Definitions
cols = [
    {
        "x": 2.0, "w": 18.0, "title": "1. PERCEPTION & SENSING", "sub": "LiDAR, Radar & Infrastructure",
        "header_color": "#0284c7", "card_bg": "#f0f9ff", "border": "#bae6fd",
        "items": [
            {"title": "Dual-Track Environment", "type": "ENV MODEL",
             "lines": ["• Track 1: Patrol line @ y = 0 m", "• Track 2: Safe home line @ y = 6 m", "• Standard Gauge: 1.435 m, Ties @ 2 m", "• Dynamic Day/Night Solar Lighting"]},
            {"title": "3D LiDAR Ray-Cast Scanner", "type": "ObstacleScanner.m",
             "lines": ["• Forward Detection Range: 32.0 m", "• Horizontal FOV: 28° radial fan", "• Corridor Filter: 1.4 m lateral width", "• Spherical-to-Cartesian hit tests"]},
            {"title": "Train Safety Radar", "type": "trainSafetyManager.m",
             "lines": ["• Train Speed: v_train = 15.0 m/s", "• Time-to-Collision: TTC = d / v_rel", "• Stopping Distance: d_stop = 66.1 m", "• Emergency Window: TTC ≤ 8.0 s"]}
        ]
    },
    {
        "x": 21.5, "w": 18.0, "title": "2. INTELLIGENCE & DECISION", "sub": "FSM & k-NN Machine Learning",
        "header_color": "#059669", "card_bg": "#f0fdf4", "border": "#bbf7d0",
        "items": [
            {"title": "12-State Finite State Machine", "type": "RobotStateMachine.m",
             "lines": ["• MOVING (2.5 m/s) → OBSTACLE", "• CLASSIFYING → APPROACHING", "• STOPPED → REMOVING / PUSHING", "• CLEARANCE_CHECK → RESUMING", "• SWITCHING → COMPLETED (Track 2)"]},
            {"title": "k-NN Action Classifier", "type": "ObstacleRemovalMLAnalyzer.m",
             "lines": ["• Model: k-NN (k = 5 neighbors)", "• Feature Vector (10D): dist, mass,", "  type, q1..q4, tipErr, v_rob, d_train", "• Classes: CONTINUE, APPROACH, PICK,", "  PLOW, EMERGENCY, RETURN", "• Validation Accuracy: 97.5%"]},
            {"title": "Safety & Clearance Arbiter", "type": "safetyDecision.m",
             "lines": ["• Corridor Risk Scoring [0 - 100]", "• Fail-safe train brake interrupt", "• Verified 3.5 m spatial clearance"]}
        ]
    },
    {
        "x": 41.0, "w": 18.0, "title": "3. PLANNING & TRAJECTORY", "sub": "Quintic S-Curves & Kinematics",
        "header_color": "#7c3aed", "card_bg": "#faf5ff", "border": "#e9d5ff",
        "items": [
            {"title": "Quintic Minimum-Jerk Generator", "type": "controlArm.m",
             "lines": ["• 5th-Order S-Curve Polynomial:", "  s(τ) = 10τ³ - 15τ⁴ + 6τ⁵  (τ ∈ [0,1])", "• Zero Boundary Jerk: J(0) = J(T) = 0", "• Continuous C² acceleration profile", "• Smooth, non-robotic arm movement"]},
            {"title": "4-DOF Kinematics & DH Chain", "type": "moveArmToObstacle.m",
             "lines": ["• Link 1 (Waist Yaw): d1 = 0.95 m", "• Link 2 (Shoulder): a2 = 0.60 m", "• Link 3 (Elbow): a3 = 0.48 m", "• Link 4 (Wrist): a4 = 0.36 m", "• Analytical Inverse Kinematics solver"]},
            {"title": "Bézier Turnout Switch", "type": "trackSwitchController.m",
             "lines": ["• Cubic Bézier Curve (L = 12.0 m)", "• Smooth lateral shift: Δy = 6.0 m", "• Transition from Track 1 to Track 2"]}
        ]
    },
    {
        "x": 60.5, "w": 18.0, "title": "4. DYNAMICS & CONTROL", "sub": "Lagrangian PD & GD Optimizer",
        "header_color": "#d97706", "card_bg": "#fffbeb", "border": "#fde68a",
        "items": [
            {"title": "Lagrangian Dynamics Engine", "type": "DynamicRobotController.m",
             "lines": ["• Equation of Motion:", "  M(q)·q̈ + C(q,q̇)·q̇ + G(q) = τ", "• 4×4 Inertia Matrix M(q)", "• Coriolis & Centrifugal Matrix C(q,q̇)", "• Payload Gravity Vector G(q)"]},
            {"title": "PD Controller + Gravity Comp", "type": "ArmDirectionController.m",
             "lines": ["• Control Torque Law:", "  τ = Kp·(q_des - q) + Kd·(q̇_des - q̇) + Ĝ(q)", "• Kp = [10.0, 55.0, 40.0, 25.0] Nm/rad", "• Kd = [ 2.5, 14.0, 10.0,  6.0] Nms/rad", "• Asymptotic Lyapunov Stability"]},
            {"title": "Gradient Descent Gain Tuner", "type": "plotMLOptimizerAnalysis.m",
             "lines": ["• Cost: L = ½||e||² + λ(||Kp||² + ||Kd||²)", "• Update: ΔKp = η(e - 2λKp)", "• RMS Error: 2.41° → 0.62° (74.3% cut)", "• Loaded Droop: 4.85° → 0.91° (81.2% cut)"]}
        ]
    },
    {
        "x": 80.0, "w": 18.0, "title": "5. DUAL ACTUATION & SAFETY", "sub": "Manipulator, Plow & Return",
        "header_color": "#dc2626", "card_bg": "#fef2f2", "border": "#fecaca",
        "items": [
            {"title": "4-DOF Arm & 535L Pouch", "type": "REMOVABLE (≤ 20 kg)",
             "lines": ["• 2-Finger Pneumatic Parallel Gripper", "• Sequence: Reach → Grasp → Lift → Drop", "• 535-Liter Rear Storage Hopper Pouch", "• Capacity: Up to 4 obstacles stored"]},
            {"title": "Articulated Front Leveler Plow", "type": "HEAVY (> 20 kg) / MUD",
             "lines": ["• 1.8 m Blade angled at 25° deflector", "• High-torque low-gear push @ 0.38 m/s", "• Deformable granular soil physics", "• Discrete 42-particle sand grain spray", "• Mud mound leveled flat (< 0.02 m)"]},
            {"title": "Safe Turnout Return", "type": "MISSION COMPLETION",
             "lines": ["• Autonomous transfer to Track 2", "• Safe parking on maintenance siding", "• Track 1 restored to 100% clearance"]}
        ]
    }
]

# Draw Columns & Module Cards
for col in cols:
    cx, cw = col["x"], col["w"]

    # Main Column Container
    col_box = patches.FancyBboxPatch((cx, 7.5), cw, 39.5, boxstyle="round,pad=0.2,rounding_size=0.6",
                                     facecolor='#ffffff', edgecolor=col["header_color"], linewidth=1.8)
    ax.add_patch(col_box)

    # Column Header Bar
    header_box = patches.FancyBboxPatch((cx, 43.5), cw, 3.5, boxstyle="round,pad=0.2,rounding_size=0.5",
                                       facecolor=col["header_color"], edgecolor='none')
    ax.add_patch(header_box)
    ax.text(cx + cw/2.0, 45.6, col["title"], ha='center', va='center',
            fontsize=11.5, fontweight='bold', color='#ffffff')
    ax.text(cx + cw/2.0, 44.2, col["sub"], ha='center', va='center',
            fontsize=8.5, fontweight='normal', color='#f1f5f9')

    # Draw Module Cards
    y_top = 42.0
    for item in col["items"]:
        card_h = 10.8 if len(item["lines"]) > 4 else 9.6
        y_pos = y_top - card_h

        card = patches.FancyBboxPatch((cx + 0.6, y_pos), cw - 1.2, card_h, boxstyle="round,pad=0.2,rounding_size=0.4",
                                      facecolor=col["card_bg"], edgecolor=col["border"], linewidth=1.2)
        ax.add_patch(card)

        # Card Title
        ax.text(cx + 1.2, y_pos + card_h - 1.1, item["title"], fontsize=9.8, fontweight='bold', color='#0f172a')
        
        # Pill Tag
        pill = patches.FancyBboxPatch((cx + cw - 1.4 - len(item["type"])*0.45, y_pos + card_h - 1.5),
                                      len(item["type"])*0.45 + 0.4, 0.9, boxstyle="round,pad=0.1,rounding_size=0.2",
                                      facecolor='#ffffff', edgecolor=col["header_color"], linewidth=0.8)
        ax.add_patch(pill)
        ax.text(cx + cw - 1.2 - (len(item["type"])*0.45)/2, y_pos + card_h - 1.05, item["type"],
                fontsize=6.8, fontweight='bold', color=col["header_color"], ha='center', va='center')

        # Card Lines
        line_y = y_pos + card_h - 2.5
        for l in item["lines"]:
            ax.text(cx + 1.2, line_y, l, fontsize=7.6, color='#334155', fontfamily='sans-serif')
            line_y -= 1.35

        y_top = y_pos - 0.7

# Connecting Arrows Between Columns
arrow_props = dict(arrowstyle="-|>", color="#64748b", lw=2.2, mutation_scale=16)
for i in range(4):
    x_start = cols[i]["x"] + cols[i]["w"] + 0.05
    x_end = cols[i+1]["x"] - 0.05
    # Connect middle of columns
    ax.annotate("", xy=(x_end, 27.5), xytext=(x_start, 27.5), arrowprops=arrow_props)
    ax.annotate("", xy=(x_end, 15.0), xytext=(x_start, 15.0), arrowprops=arrow_props)

# Bottom Supervisory & Telemetry Layer
telemetry_box = patches.FancyBboxPatch((1.5, 0.8), 97, 5.5, boxstyle="round,pad=0.2,rounding_size=0.6",
                                      facecolor='#0f172a', edgecolor='#38bdf8', linewidth=1.5)
ax.add_patch(telemetry_box)

ax.text(3.5, 4.3, "REAL-TIME SUPERVISION & TELEMETRY SUBSYSTEM (20 Hz CLOCK CYCLE)",
        fontsize=10.5, fontweight='bold', color='#38bdf8')

telemetry_items = [
    "• 3D OpenGL Viewport: Third-person chase camera, dynamic lighting, real-time kinematics mesh rendering",
    "• App Designer Dashboard: Live gauge cluster, robot speed, TTC warning lamps, 535L pouch LED occupancy [0-4]",
    "• HUD Viewport Overlays: Live 4-joint angle readouts (q1-q4), ML confidence score, current FSM state display",
    "• Telemetry Black-Box: Auto-generates Data/simulationLog.csv with timestamped states, torques, errors & event history"
]

ty = 3.0
for ti in telemetry_items:
    ax.text(3.5, ty, ti, fontsize=8.2, color='#e2e8f0', fontfamily='sans-serif')
    ty -= 1.05

# Save High-DPI Output
output_path = r"c:\Users\hp\OneDrive\Documents\RailwayRobotSimulation\RailwayRobotSimulation\Project_Architecture_Diagram_HD.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor=fig.get_facecolor(), edgecolor='none')
plt.close()
print("SUCCESS: Generated Project_Architecture_Diagram_HD.png")
