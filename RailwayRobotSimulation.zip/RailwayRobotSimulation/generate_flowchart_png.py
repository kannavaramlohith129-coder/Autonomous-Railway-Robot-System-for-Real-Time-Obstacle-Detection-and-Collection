import matplotlib.pyplot as plt
import matplotlib.patches as patches

fig = plt.figure(figsize=(19, 10.7), dpi=300)
ax = fig.add_subplot(111)
ax.set_xlim(0, 100)
ax.set_ylim(0, 56)
ax.axis('off')

fig.patch.set_facecolor('#ffffff')
ax.set_facecolor('#ffffff')

# Header Title Box
title_box = patches.FancyBboxPatch((1.5, 48.2), 97, 6.6, boxstyle="round,pad=0.3,rounding_size=0.8",
                                  facecolor='#0f172a', edgecolor='#0284c7', linewidth=2.5)
ax.add_patch(title_box)

ax.text(50, 52.6, "AUTONOMOUS RAILWAY ROBOT SIMULATION — SYSTEM FLOWCHART",
        ha='center', va='center', fontsize=17, fontweight='bold', color='#ffffff', fontfamily='sans-serif')
ax.text(50, 50.0, "End-to-End Operational Flow: LiDAR Sensing • k-NN AI Classifier • Quintic S-Curves • Arm Pouch & Plow Push • Bézier Safe Return",
        ha='center', va='center', fontsize=10.5, fontweight='medium', color='#94a3b8', fontfamily='sans-serif')

# Column Definitions
stages = [
    {"x": 1.5, "w": 18.0, "title": "1. PATROL & SENSING", "sub": "LiDAR, Radar & Infrastructure", "color": "#0284c7"},
    {"x": 21.0, "w": 18.5, "title": "2. DETECTION & ML DECISION", "sub": "10D Features & k-NN (97.5%)", "color": "#059669"},
    {"x": 41.0, "w": 24.5, "title": "3. DUAL CLEARANCE EXECUTION", "sub": "Quintic Arm & Leveler Plow", "color": "#7c3aed"},
    {"x": 67.0, "w": 16.5, "title": "4. SAFETY VERIFICATION", "sub": "Clearance & Train Radar", "color": "#e11d48"},
    {"x": 85.0, "w": 13.5, "title": "5. SAFE RETURN", "sub": "Bézier & Telemetry", "color": "#16a34a"}
]

for st in stages:
    box = patches.FancyBboxPatch((st["x"], 1.5), st["w"], 45.2, boxstyle="round,pad=0.2,rounding_size=0.6",
                                facecolor='#f8fafc', edgecolor='#cbd5e1', linewidth=1.5)
    ax.add_patch(box)
    
    header = patches.FancyBboxPatch((st["x"], 43.2), st["w"], 3.5, boxstyle="round,pad=0.2,rounding_size=0.4",
                                   facecolor=st["color"], edgecolor='none')
    ax.add_patch(header)
    ax.text(st["x"] + st["w"]/2, 45.4, st["title"], ha='center', va='center',
            fontsize=10.5, fontweight='bold', color='#ffffff')
    ax.text(st["x"] + st["w"]/2, 44.1, st["sub"], ha='center', va='center',
            fontsize=7.8, fontweight='normal', color='#f1f5f9')

# Draw Flowchart Nodes Helper
def draw_node(x, y, w, h, title, sub, math_text="", bg="#ffffff", border="#64748b", shape="rect", text_color="#0f172a"):
    if shape == "pill":
        node = patches.FancyBboxPatch((x, y), w, h, boxstyle=f"round,pad=0.2,rounding_size={h/2}",
                                      facecolor=bg, edgecolor=border, linewidth=2.0)
    elif shape == "diamond":
        poly = patches.Polygon([[x+w/2, y+h], [x+w, y+h/2], [x+w/2, y], [x, y+h/2]],
                               closed=True, facecolor=bg, edgecolor=border, linewidth=2.0)
        ax.add_patch(poly)
        node = None
    else:
        node = patches.FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=0.4",
                                      facecolor=bg, edgecolor=border, linewidth=1.5)
    if node:
        ax.add_patch(node)
    
    # Texts
    if math_text:
        ax.text(x+w/2, y+h*0.72, title, ha='center', va='center', fontsize=9.2, fontweight='bold', color=text_color)
        ax.text(x+w/2, y+h*0.48, sub, ha='center', va='center', fontsize=7.6, color='#475569')
        ax.text(x+w/2, y+h*0.22, math_text, ha='center', va='center', fontsize=7.2, color='#0284c7', fontfamily='monospace')
    elif sub:
        ax.text(x+w/2, y+h*0.65, title, ha='center', va='center', fontsize=9.2, fontweight='bold', color=text_color)
        ax.text(x+w/2, y+h*0.35, sub, ha='center', va='center', fontsize=7.6, color='#475569')
    else:
        ax.text(x+w/2, y+h*0.5, title, ha='center', va='center', fontsize=9.5, fontweight='bold', color=text_color)

# Stage 1 Nodes
draw_node(3.0, 37.5, 15.0, 4.2, "START SIMULATION", "", bg="#0284c7", border="#0369a1", shape="pill", text_color="#ffffff")
draw_node(2.5, 29.5, 16.0, 6.2, "1. Autonomous Patrol", "Cruising Track 1 @ 2.5 m/s", "Acc = 1.8 m/s² | Day/Night Light", border="#94a3b8")
draw_node(2.5, 20.5, 16.0, 6.8, "2. 3D LiDAR Scanner", "Forward Range: 32.0 m (28° FOV)", "Corridor Filter: |Δy| ≤ 1.4 m", border="#0284c7")
draw_node(2.5, 11.5, 16.0, 6.8, "3. Train Collision Radar", "v_train = 15.0 m/s Tracking", "TTC = d_rel / (v_train + v_rob)", border="#e11d48")

# Stage 2 Nodes
draw_node(22.0, 36.5, 16.5, 5.5, "All Obstacles Cleared?", "Patrol limit x ≥ 180 m", shape="diamond", bg="#f0fdf4", border="#16a34a")
draw_node(22.0, 27.5, 16.5, 6.0, "Corridor Obstacle", "Detected on Track 1?", shape="diamond", bg="#f8fafc", border="#475569")
draw_node(22.0, 18.5, 16.5, 6.8, "10-D Feature Extractor", "Extract [d, m, type, q1..q4,", "e_tip, v_rob, d_train]", border="#059669")
draw_node(22.0, 9.5, 16.5, 6.8, "k-NN Action Classifier", "k = 5 | 97.5% Acc | Pouch [0-4]", "Predicts: ARM_PICK / PLOW_PUSH", bg="#f0fdf4", border="#16a34a", text_color="#15803d")

# Stage 3 Nodes (Dual Branches)
# Top: Arm Pick
draw_node(42.0, 32.0, 10.8, 8.5, "1. Quintic S-Curve", "Zero Boundary Jerk", "s(τ)=10τ³-15τ⁴+6τ⁵", bg="#f0fdf4", border="#16a34a", text_color="#14532d")
draw_node(53.8, 32.0, 11.0, 8.5, "2. Arm Pick & Pouch", "Lagrangian PD + GD Tuner", "Deposit into 535L Pouch", bg="#ffffff", border="#16a34a", text_color="#0f172a")

# Bottom: Plow Push
draw_node(42.0, 9.5, 10.8, 8.5, "1. Leveler Blade", "Extend 1.8 m Blade", "Angle: 25° Deflector", bg="#f0f9ff", border="#0284c7", text_color="#0369a1")
draw_node(53.8, 9.5, 11.0, 8.5, "2. Heavy Push & Berm", "Low Gear @ 0.38 m/s", "Soil Mechanics + 42 Spray", bg="#ffffff", border="#0284c7", text_color="#0f172a")

# Stage 4 Nodes
draw_node(68.0, 31.0, 14.5, 6.5, "Track Clearance Check", "3.5 m Envelope 100% Cleared", "LiDAR Verification", border="#475569")
draw_node(68.0, 20.5, 14.5, 6.8, "Track Clear &", "Train TTC > 8.0 s?", shape="diamond", bg="#f8fafc", border="#475569")
draw_node(68.0, 11.0, 14.5, 6.2, "Resume Patrol Loop", "Accelerate back to 2.5 m/s", "LED turns GREEN", bg="#ecfdf5", border="#16a34a", text_color="#14532d")

# Emergency Branch in Stage 4
draw_node(68.0, 2.8, 14.5, 5.5, "EMERGENCY STOP", "Max Braking | Alarm ON", bg="#fef2f2", border="#dc2626", text_color="#b91c1c")

# Stage 5 Nodes
draw_node(86.0, 33.5, 11.5, 6.5, "Bézier Track Switch", "L = 12m Turnout Curve", "Shift to Track 2 (y = 6m)", bg="#f0fdf4", border="#16a34a", text_color="#14532d")
draw_node(86.0, 22.5, 11.5, 6.5, "MISSION COMPLETE", "Safely Parked on Siding", "Track 1 Restored", bg="#15803d", border="#166534", shape="pill", text_color="#ffffff")
draw_node(86.0, 11.5, 11.5, 6.5, "Telemetry Black-Box", "simulationLog.csv Saved", "App Designer Data Log", bg="#0f172a", border="#38bdf8", text_color="#38bdf8")

# Arrows
arr = dict(arrowstyle="-|>", color="#475569", lw=1.8, mutation_scale=13)
arr_green = dict(arrowstyle="-|>", color="#15803d", lw=2.0, mutation_scale=13)
arr_blue = dict(arrowstyle="-|>", color="#0284c7", lw=2.0, mutation_scale=13)
arr_red = dict(arrowstyle="-|>", color="#dc2626", lw=2.0, mutation_scale=13)

# S1 Flow
ax.annotate("", xy=(10.5, 35.7), xytext=(10.5, 37.5), arrowprops=arr)
ax.annotate("", xy=(10.5, 27.3), xytext=(10.5, 29.5), arrowprops=arr)
ax.annotate("", xy=(10.5, 18.3), xytext=(10.5, 20.5), arrowprops=arr)
ax.annotate("", xy=(22.0, 30.5), xytext=(18.5, 23.9), arrowprops=arr)

# S2 Flow
ax.annotate("", xy=(30.25, 36.5), xytext=(30.25, 33.5), arrowprops=arr)  # Obs [NO] -> All clear
ax.annotate("", xy=(30.25, 25.3), xytext=(30.25, 27.5), arrowprops=arr)  # Obs [YES] -> Features
ax.annotate("", xy=(30.25, 16.3), xytext=(30.25, 18.5), arrowprops=arr)  # Features -> k-NN

# Top arm pick path
ax.annotate("", xy=(42.0, 36.2), xytext=(38.5, 14.5), arrowprops=arr_green)
ax.text(37.5, 37.0, "Removable (≤20kg)\nPouch < 4", fontsize=7.2, fontweight='bold', color='#15803d')

# Bottom plow push path
ax.annotate("", xy=(42.0, 13.7), xytext=(38.5, 12.0), arrowprops=arr_blue)
ax.text(37.5, 10.0, "Heavy (>20kg) /\nPouch Full", fontsize=7.2, fontweight='bold', color='#0284c7')

# Arm Step 1 -> Step 2
ax.annotate("", xy=(53.8, 36.2), xytext=(52.8, 36.2), arrowprops=arr_green)
# Plow Step 1 -> Step 2
ax.annotate("", xy=(53.8, 13.7), xytext=(52.8, 13.7), arrowprops=arr_blue)

# Arm & Plow to Stage 4 Clearance
ax.annotate("", xy=(68.0, 34.5), xytext=(64.8, 36.2), arrowprops=arr_green)
ax.annotate("", xy=(68.0, 33.0), xytext=(64.8, 13.7), arrowprops=arr_blue)

# Stage 4 Flow
ax.annotate("", xy=(75.25, 27.3), xytext=(75.25, 31.0), arrowprops=arr)
ax.annotate("", xy=(75.25, 17.2), xytext=(75.25, 20.5), arrowprops=arr_green)
ax.text(76.2, 18.8, "YES (Safe)", fontsize=7.2, fontweight='bold', color='#15803d')

ax.annotate("", xy=(75.25, 8.3), xytext=(75.25, 11.0), arrowprops=arr) # Resume to loop
ax.annotate("", xy=(75.25, 20.5), xytext=(75.25, 8.3), arrowprops=arr_red) # Emergency
ax.text(76.2, 9.8, "NO (TTC ≤ 8s)", fontsize=7.2, fontweight='bold', color='#dc2626')

# All clear -> Stage 5 Bézier Switch
ax.annotate("", xy=(86.0, 36.7), xytext=(38.5, 39.2), arrowprops=arr_green)
ax.text(60.0, 41.5, "All Obstacles Cleared (x ≥ 180m)", fontsize=8.0, fontweight='bold', color='#15803d')

# S5 Flow
ax.annotate("", xy=(91.75, 29.0), xytext=(91.75, 33.5), arrowprops=arr_green)
ax.annotate("", xy=(91.75, 18.0), xytext=(91.75, 22.5), arrowprops=arr)

output_path = r"c:\Users\hp\OneDrive\Documents\RailwayRobotSimulation\RailwayRobotSimulation\Project_Flowchart_HD.png"
plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='#ffffff', edgecolor='none')
plt.close()
print("SUCCESS: Generated Project_Flowchart_HD.png")
